# SDR# SWL Knowledge Database (VLF to microwave; no ULF)

Generated 2026-09-13. This is a curated receiver bookmark set, not a claim that every listed transmitter is active at every moment. It contains 97 defensible landmarks covering VLF/LF stations, time signals, maritime and aeronautical safety/data channels, amateur weak-signal dial frequencies, satellite segments and microwave references. ULF is intentionally excluded.

## Files

- **Frequencies.xml** — SDR# default Frequency Manager XML. Back up your existing file before replacing or merging it. SDR# versions and third-party Frequency Manager plugins can use different stores; some use SQLite rather than this XML.
- **sdrsharp_swl_database.csv** — full metadata and source notes.
- **sdrsharp_swl_database.xlsx** — filterable reference workbook with a Summary and Database sheet.

## Import

1. Close SDR#.
2. Back up the current Frequencies.xml in the SDR# program/configuration folder.
3. Copy this Frequencies.xml there, or merge its MemoryEntry blocks into your existing file.
4. Reopen SDR# and enable display of frequency labels/bookmarks.

If you use Frequency Manager Suite, import the CSV with its Data Tools Wizard and map Frequency_Hz, Label, Group, Mode and Bandwidth_Hz. Do not rename a SQLite database to XML.

## Scope and cautions

Schedules, military callsigns, broadcast assignments and satellite status change. Entries labelled **Schedule-dependent**, **Reported**, **Reference**, or **Band marker** are clues for identification, not confirmation. HF broadcast schedules belong in a seasonal loader such as HFCC/EiBi; duplicating thousands of schedule rows in SDR# creates unreadable overlays. The official HFCC A26 operational archive was last updated 2026-09-11 and remains the right seasonal source: https://new.hfcc.org/data/

Receiver mode is a practical starting point. For FSK/MSK/DSC/NAVTEX decoding, the decoder may require a particular USB audio offset rather than direct zero-beat tuning. Never transmit on safety, aviation, maritime, military, satellite or licence-exempt channels unless your licence and local law explicitly permit it.
